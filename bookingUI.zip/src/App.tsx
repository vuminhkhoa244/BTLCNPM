import React from "react";
import BookingUI from "./BookingUI";

export default function App() {
  return <BookingUI />;
}
